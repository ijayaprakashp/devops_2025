# a = False
# b = True


# if a and b:
#     print("Yes")
#     print("The")
# print("condition")

# print("Execution Comlpeted!")


# num1 = 100
# num2 = 200

# if num1 > num2:
#     print(f"num1 ({num1}) is greater than num2 ({num2}) ")
# else:
#     print(f"num1 ({num1}) is less than num2 ({num2}) ")

# print("Execution Comlpeted!")


# num1 = 13
# num2 = 16
# num3 = 16

# if num1 > num2 and num1 > num3:
#     print("num1 is gratest")
# elif num2 > num1 and num2 > num3:
#     print("num2 is gratest")
# elif num3 > num1 and num3 > num2:
#     print("num3 is gratest")
# else:
#     print("All are equal")

num1 = 13
num2 = 16
num3 = 16

# if num1 == num2:
#     print("num1 and num2 are equal")
# else:
#     print("num1 and num2 are not equal")

# if num1 == num3:
#     print("num1 and num3 are equal")
# else:
#     print("num1 and num3 are not equal")


if num1 > num2:
    if num1 > num3:
        print("num1 is gratest")
    elif num1 == num3:
        print("num1 and num3 are equal and greater than 2")
    else:
        print("num3 is gratest")
elif num1 == num2:
    if num1 > num3:
        print("num1 and num2 are equal and greater than 3")
    else:
        print("num3 is gratest")

if num1 > num2:
    print("==========")


