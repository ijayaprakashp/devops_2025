number1to10 = 10
